x = int(input('Van welke tafel wilt u vermenigvuldigingen zien?: '))
for i in range(1, 11):
    print(x * i)